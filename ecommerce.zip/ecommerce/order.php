<?php
require 'database/config.php';
include("functions/function.php");
if(isset($_GET['c_id'])){
	$customer_id=$_GET['c_id'];
	$query6="select * from customer where customer_id='$customer_id'";
	$runquery6=mysqli_query($con,$query6);
	$rowquery6=mysqli_fetch_array($runquery6);
	$customer_email=$rowquery6['Email'];
	$customer_name=$rowquery6['customer_name'];
}
	$ip=getUserIpAddr();
	$query="select * from cart where ip_add='$ip'";
	$runquery=mysqli_query($con,$query);
	$countpro=mysqli_num_rows($runquery);
	$nettotal=0;
	$status='Pending';
	$invoice_no=mt_rand();
	$i=0;
	while($row=mysqli_fetch_array($runquery)){
	$prod_id=$row['cart_id'];
	$qty=$row['qty'];
	$tt="select * from products where product_id='$prod_id'";
	$at=mysqli_query($con,$tt);
	while($rowdata=mysqli_fetch_array($at)){
		$product_id=$rowdata['product_id'];
		$product_title=$rowdata['product_title'];
		$product_price=$rowdata['product_price'];
		$product_img=$rowdata['img1'];
		$subtotal=$product_price*$qty;
		$nettotal=$nettotal+$subtotal;
	$i++;
	$insertpending="insert into customer_pending(customer_id,invoice_no,product_id,qty,order_status) values('$customer_id','$invoice_no','$product_id','$qty','$status')";
	$runinsertpending=mysqli_query($con,$insertpending);
		$cartdelete="delete from cart where ip_add='$ip'";
	$runcartquery=mysqli_query($con,$cartdelete);
	}
	}
 $qt="insert into customer_orders (customer_id,due_amount,invoice_no,total_products,order_date,order_status) values
('$customer_id','$nettotal','$invoice_no','$countpro',NOW(),'$status')";
$runinsert=mysqli_query($con,$qt);
$from='admin@academy.com';
$subject='Orders Details';
$message="
	<html>
	<p>Hello Sir $customer_name you have ordered products from my mysite.coms</p>
	<table width='600' align='center' bgcolor='#FEC606' border='2'>
	<tr><td> Your Order details from www.mysite.com</td><tr>
	<tr>
	<th>S.N</th>
	<th>Product Name</th>
	<th>Product Quantity</th>
	<th>Total Price</th>
	<th>Invoice No</th>	
	</tr>
	<tr>
	<td>$i</td>
	<td>$product_title</td>
	<td>$qty</td>
	<td>$$subtotal</td>
	<td>$invoice_no</td>
	</tr>
	</table>
	<h3>Please go to your mysite.com account and pay the due payments</h3>
	<h2><a href='mysite.com'>Click</a> here to login your account</h2>
	<h3>Thanks for the Order from www.mysite.com</h3>
	</html>
	";
	mail($customer_email,$subject,$message,$from);
echo '<script>alert("Order has been successfully submitted,Thanks")</script>';
echo "<script>window.open('Myaccount.php','_self')</script>";
?>
<?php
require 'database/config.php';
include("functions/function.php");
echo delete_cart();
?>
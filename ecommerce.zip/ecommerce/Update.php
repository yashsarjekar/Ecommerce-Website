<?php
require 'database/config.php';
include("functions/function.php");
echo Update_cart();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Mainpage</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#E0E4CC" id="bodystyle" >
<div id="pagelayout" >
  <div class="product-card">
    <div class="product-image">
      <img src="logopic.png">
    </div>
    <div class="product-info">
      <h5>Winter Jacket</h5>
      <h6>$99.99</h6>
    </div>
  </div>
  <div class="product-card">
    <div class="product-image">
      <img src="logopic.png">
    </div>
    <div class="product-info">
      <h5>Winter Jacket</h5>
      <h6>$99.99</h6>
    </div>
  </div>
</div>
</body>
</html>
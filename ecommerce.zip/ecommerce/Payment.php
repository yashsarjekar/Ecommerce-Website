<!DOCTYPE HTML>
<html>
<head>
<title>Payment Page</title>
</head>
<body>
<?php
require 'database/config.php';
?>

<?php
$ip=getUserIpAddr();
$query="select * from customer where customer_ip='$ip'";
$run=mysqli_query($con,$query);
$rowquery=mysqli_fetch_array($run);
$customer_id=$rowquery['customer_id'];
?>
<h5><a href="order.php?c_id=<?php echo $customer_id;?>"><button name="payment">PayOnline</button></h5>
</form>
</body>
</html>